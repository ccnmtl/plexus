ADAPTOR_INPLACEEDIT = {
                       'text': 'inplaceeditform.fields.AdaptorTextField',
                       'textarea': 'inplaceeditform.fields.AdaptorTextAreaField',
                       'choices': 'inplaceeditform.fields.AdaptorChoicesField',
                       'boolean': 'inplaceeditform.fields.AdaptorBooleanField',
                       'date': 'inplaceeditform.fields.AdaptorDateField',
                       'datetime': 'inplaceeditform.fields.AdaptorDateTimeField',
                       'fk': 'inplaceeditform.fields.AdaptorForeingKeyField',
                       'm2m': 'inplaceeditform.fields.AdaptorManyToManyField',
                       'm2mcomma': 'inplaceeditform.fields.AdaptorCommaSeparatedManyToManyField',
                       'file': 'inplaceeditform.fields.AdaptorFileField',
                       'image': 'inplaceeditform.fields.AdaptorImageField',
                       }
