The PRIMARY AUTHORS are (ordered by aproximated LOC number):

 * Pablo Martín Cobos <pmartin (_at_) yaco.es>
 * Rosa Durante <rosunix (_at_) gmail.com>


Other inplaceedit DEVELOPERS are:

 * Javier de la Rosa <versae (_at_) gmail.com>
 * Jorge Correa <jcorrea (_at_) yaco.es>
 * Isabel Serván <iservan (_at_) yaco.es>
 * Emilio Sanchez <esanchez (_at_) yaco.es>